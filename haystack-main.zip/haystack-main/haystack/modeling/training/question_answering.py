# TODO make QA_Trainer class and use insider reader.train
