from rest_api.pipeline import custom_component  # this import is required for the Custom Components to be registered
