from haystack.nodes.prompt.prompt_node import PromptNode, PromptTemplate, PromptModel
